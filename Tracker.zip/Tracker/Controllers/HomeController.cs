using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Tracker.Models;

namespace Tracker.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        return View();  // This will look for Views/Home/Index.cshtml
    }

    public IActionResult courses()
    {
        return View("courses");  // This will look for Views/Home/Courses.cshtml
    }

    public IActionResult progress()
    {
        return View("progress");  // This will look for Views/Home/Progress.cshtml
    }

    public IActionResult about()
    {
        return View("about");  // This will look for Views/Home/About.cshtml
    }

        public IActionResult certifications()
    {
        return View("certifications"); 
    }
}
